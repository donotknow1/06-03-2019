package com.bank.dao;


import java.util.List;

import com.bank.entity.AccountMaster;
import com.bank.entity.Customer;
import com.bank.entity.Payee;
import com.bank.entity.ServiceTracker;
import com.bank.entity.Transactions;
import com.bank.entity.UserTable;
import com.bank.exception.BankingException;

public interface IBankRepository {
  

public UserTable check(UserTable user);

public AccountMaster getAccountBalance(long accId);

public int getChangeAddress(long accId, String cadd);

public int getChangeMobNum(long accId,String cmob);

public int getChangePassWord(long accId, String cpw);
public List<Transactions> loadAllTransactions();

public Customer add(Customer customer);

int login(int adminId, String password);
public UserTable checkPassWord(UserTable user);


public UserTable checkSecret(String secret,int uid);

 
public int changePassword(int userId, String pass);





public List<Transactions> loadDateTransactions(String  dateOfTransaction);




public List<Transactions> loadMonthTransactions(String monthTransaction);




public List<Transactions> loadYearTransactions(String yearTransaction);




public int getservId(long accId);




public String getServiceTracker(int sid);




public int getCheckBook(ServiceTracker st);




public List<Transactions> loadMiniStatement(long accId);

public List<Transactions> loadDetailedStatement(String startDate,String endDate,long accId);

public int add(UserTable usertable);


//transactions

public List<Payee> getAllUser(long accountId) throws BankingException;

public boolean fundTransfer(long accno,long payeraccno, double amount,String paymtd) throws BankingException;

public boolean fundPayer(long accountId, double amount) throws BankingException;

public boolean addPayee(Payee payee) throws BankingException;

public boolean checkPayee(long paccId) throws BankingException;

public AccountMaster adds(AccountMaster a);
}
