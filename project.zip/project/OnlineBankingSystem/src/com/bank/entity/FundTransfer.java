package com.bank.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="fund_transfer")
public class FundTransfer {
	
	@Id
	  private int fundId;
	  private long senderAccountNum;
	  private String transpwd;
	  private long payeeAccId;
	  private String dateOfTransfer;
	  private double transferAmt;
	public int getFundId() {
		return fundId;
	}
	public void setFundId(int fundId) {
		this.fundId = fundId;
	}
	public long getSenderAccountNum() {
		return senderAccountNum;
	}
	public void setSenderAccountNum(long senderAccountNum) {
		this.senderAccountNum = senderAccountNum;
	}
	public String getTranspwd() {
		return transpwd;
	}
	public void setTranspwd(String transpwd) {
		this.transpwd = transpwd;
	}
	public long getPayeeAccId() {
		return payeeAccId;
	}
	public void setPayeeAccId(long accountId) {
		this.payeeAccId = accountId;
	}
	public String getDateOfTransfer() {
		return dateOfTransfer;
	}
	public void setDateOfTransfer(String dateOfTransfer) {
		this.dateOfTransfer = dateOfTransfer;
	}
	public double getTransferAmt() {
		return transferAmt;
	}
	public void setTransferAmt(double transferAmt) {
		this.transferAmt = transferAmt;
	}
	  
	  
}
