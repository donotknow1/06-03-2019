package com.bank.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="service_tracker")
public class ServiceTracker  {
	@Id
	@SequenceGenerator(name="serviceId",sequenceName="serviceId", initialValue = 1234,allocationSize= 12345)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="serviceId") 
	private int serviceId;
	private String serviceDescription;
	private long accountId;
	private String serviceRequestDate;
	private String serviceStaus;
	
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceDescription() {
		return serviceDescription;
	}
	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public String getServiceRequestDate() {
		return serviceRequestDate;
	}
	public void setServiceRequestDate(String serviceRequestDate) {
		this.serviceRequestDate = serviceRequestDate;
	}
	public String getServiceStaus() {
		return serviceStaus;
	}
	public void setServiceStaus(String serviceStaus) {
		this.serviceStaus = serviceStaus;
	}
	
	
}
