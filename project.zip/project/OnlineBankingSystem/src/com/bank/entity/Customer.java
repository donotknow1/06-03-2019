package com.bank.entity;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

@Entity 
 public class Customer implements Serializable{
  
  @Id
  @SequenceGenerator(name="acc_Id",sequenceName="acc_Id", initialValue = 123456789,allocationSize= 123456789)
  @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="acc_Id" )
  private long accountId;
  
  @NotEmpty(message="customer name is mandatory")
  @Size(min=3,max=15,message="minimum 3 letters")
  private String customerName;
  
  @NotEmpty(message="Email is mandatory")
  @Size(min=7,message="minimum 3 letters")
  private String customerEmail;
  
  @NotEmpty(message="Mobile number is mandatory")
  @Size(min=10,message="minimum 10 digits")
  private String customerMobNum;
  
  @NotEmpty(message="Address is mandatory")
  @Size(min=5,message="minimum 10 letters")
  private String customerAddress;
  
  private String accountType;
  
  //@NotEmpty(message="opening balance is mandatory")
 // @Size(min=4,max=5,message="minimum 4 digits")
  private int openingBalance;
  
  @NotEmpty(message="pan card is mandatory")
  @Size(min=10,message="minimum 10 characters")
  private String pancard; 
  
  public long getAccountId() {
   return accountId;
  }
  public void setAccountId(long accountId) {
   this.accountId = accountId;
  }
  public String getCustomerName() {
   return customerName;
  }
  public void setCustomerName(String customerName) {
   this.customerName = customerName;
  }
  public String getCustomerEmail() {
   return customerEmail;
  }
  public void setCustomerEmail(String customerEmail) {
   this.customerEmail = customerEmail;
  }
  public String getCustomerMobNum() {
   return customerMobNum;
  }
  public void setCustomerMobNum(String customerMobNum) {
   this.customerMobNum = customerMobNum;
  }
  public String getCustomerAddress() {
   return customerAddress;
  }
  public void setCustomerAddress(String customerAddress) {
   this.customerAddress = customerAddress;
  }
  public String getAccountType() {
   return accountType;
  }
  public void setAccountType(String accountType) {
   this.accountType = accountType;
  }
  public int getOpeningBalance() {
   return openingBalance;
  }
  public void setOpeningBalance(int openingBalance) {
   this.openingBalance = openingBalance;
  }
  public String getPancard() {
   return pancard;
  }
  public void setPancard(String pancard) {
   this.pancard = pancard;
  }
  
  
 }

