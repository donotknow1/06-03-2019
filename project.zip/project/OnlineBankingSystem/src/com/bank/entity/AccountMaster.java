package com.bank.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="AccountMaster")
public class AccountMaster {
	@Id
	@Column(name="ACCOUNTID")
	 private long accountId;
	@Column(name="ACCOUNTBALANCE")
	 private double accountBalance;
	@Column(name="ACCOUNTTYPE")
	 private String accountType;
	
	@Column(name="OPENINGDATE")
	 private String openingDate;
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double d) {
		this.accountBalance = d;
	}
	public String getOpeningDate() {
		return openingDate;
	}
	public void setOpeningDate(String openingDate) {
		this.openingDate = openingDate;
	}
	  
	  
	  
}
