package com.bank.controller;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.jboss.security.auth.spi.Users.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;














import org.springframework.web.servlet.ModelAndView;

import com.bank.entity.AccountMaster;
import com.bank.entity.Admin;
import com.bank.entity.Customer;
import com.bank.entity.Payee;
import com.bank.entity.ServiceTracker;
import com.bank.entity.Transactions;
import com.bank.entity.UserTable;
import com.bank.exception.BankingException;
import com.bank.service.BankService;
import com.bank.service.IBankService;
import com.sun.org.apache.xalan.internal.xsltc.compiler.sym;

@Controller
public class BankController {
	@Autowired
	public IBankService bankService;
	
	 
	static int userId;
	static long accId;
	static int adminid;
	static String dateOfTransaction;
	static int serviceId;
	static UserTable user1;

	
	@RequestMapping("/index")
	public String showIndex(Model model){
		return "index";
	}
	

	@RequestMapping(value= "/loginPage")
	public String showLoginPage(Model model) throws BankingException{	
		try{
	 model.addAttribute("UserTable",new UserTable());
		}
		catch(Exception e){
			throw new BankingException("Error in Logging"+e);
		}
		return "loginPage";
	}
	
//******************************************USER SignUp******************************************//
	   @RequestMapping("/usersignup")
	    public String saves(Model model){
	    	model.addAttribute("useraccount",new UserTable());
	    	return "usersignup";
	    }
	   @RequestMapping(value="/usersignup2")
	    public String userSignUp(@ModelAttribute("useraccount")UserTable usertable, Model model){
	    	
	    	int userids =bankService.add(usertable);
	    		model.addAttribute("userId", userids);
	    		return "usersignup2";
	    	}
	    
	    @RequestMapping(value="/forgotPassword")	    
	    public String forgotPass(Model model){	     
	    model.addAttribute("UserTable",new UserTable());	     
	    return "forgotPassword";

	    }
	     
	    @RequestMapping(value="/forgotPassword1")	     
	    public String forgotPassword(@ModelAttribute("UserTable")UserTable user,Model model){	     
	    String secretQ=user.getSecretQuestion();	     
	    userId=user.getUserId();	     
	    model.addAttribute("changePassWord",new UserTable()); 	     
	    model.addAttribute("secret",bankService.checkSecret(secretQ,userId)); 	     
	    return "changePassWord";

	    }

	     
	    @RequestMapping(value="successPassWord1")	     
	    public String password(Model model,@ModelAttribute("changePassWord")UserTable user){	     
	    String pass=user.getLoginPassword();	     
	    model.addAttribute("changePassWord",bankService.getpassword(userId,pass));	     
	    return "successPassWord";

	    }

	    	
	    	
	   
	
//####################################### ACCOUNT HOLDER ##########################################//	
//*************************************ACCOUNTID***************************************************//
    @RequestMapping(value="/accountHolder")
		public String login(@ModelAttribute("accountHolder")UserTable user,@RequestParam("userId")int uid,Model model){
			userId=uid;
			UserTable users=null;
	       //model.addAttribute("bank",bankService.check(user));
		   //model.addAttribute("message","successfully loggedin!");
		   users=bankService.check(user);
		   System.out.println(users);
		  // UserTable user1=   bankService.check(users);
		   if(users!=null)
		   {
			   model.addAttribute("message","login successful!!!");
		       accId=users.getAccountId();
		       return "accountHolder";
			  
		   }
		   else
		   {
			   model.addAttribute("message","wrong credentials.......try again");
			   model.addAttribute("users", new UserTable());
			   return "redirect:/loginPage.html";
		} 
    }
    @RequestMapping(value="/accountHolder1")
    public String  show(Model model){
    	
          return "accountHolder";
  	  
    }
    
    
//*************************************ACCOUNT BALANCE**********************************************//  
   
    @RequestMapping(value="/accountBalance")
      public String  showaccountbalance(Model model){
    	 model.addAttribute("accbalance",bankService.getAccountBalance(accId));
            return "accountBalance";
    	  
      }
      
    
//*************************  CHANGE ADDRESSS ***********************************************//
    @RequestMapping(value= "/changeAddress")
	public String showAddressPage(Model model){
		model.addAttribute("customer",new Customer());
		return  "changeAddress";
	}
    
    
    @RequestMapping(value="/successAdd")    
    public String showchangeAddress(Model model,@ModelAttribute("changeAddress")Customer cust){     
    String cadd=cust.getCustomerAddress();     
    int res = bankService.getChangeAddress(accId,cadd);     
    if (res>0){
    model.addAttribute("changeAddress",cadd);
    return "successAdd";
    }
	return "error";
    }

      
//********************** CHANGE PHONE NUMBER**************************************************//
     @RequestMapping(value= "/changePhone")
  	public String showchangePhone(Model model){
  		model.addAttribute("customer",new Customer());
  		return  "changePhone";
  	}

    @RequestMapping(value="/successPhone")
    public String showchangePhone(Model model,@ModelAttribute("changePhone")Customer cus){
    	String cmob=cus.getCustomerMobNum();
    	int res=bankService.getChangeMobNum(accId,cmob);
    	 
        if (res>0){
        model.addAttribute("changePhone",cmob);
        return "successPhone";
        }
        return "error";
        }
       
  	  
  
 
//*********************************UPDATE PASSWORD*********************************************//
     
    @RequestMapping(value= "/changePassword1") 
   public String showchangePassWord(Model model){ 
      model.addAttribute("changePassword1",new UserTable()); 
      return "changePassword1";

      }

 
    @RequestMapping(value="/successPassWord") 
   public String showchangePassWord(Model model,@ModelAttribute("changePassword1")UserTable ut){ 
	String cpw=ut.getLoginPassword();	 
	model.addAttribute("changePassword1",bankService.getChangePassWord(accId,cpw));	 
	return "successPassWord";
    }

    
    

//*****************************viewMiniStatement************************************************//
   
    	@RequestMapping("/viewStatement")
    	public String viewStatement() {
    	       return "viewStatement";
            }    
    	    
    	@RequestMapping("/viewMiniStatement")    	 
    	public String viewMiniStatement() {    	 
    	return "miniStatement";
    	}
    	 
    	@RequestMapping(value="miniStatement")
    	 public String getMiniStatement(Model model) throws BankingException{
    		try{
    	 model.addAttribute("bankList", bankService.loadMiniStatement(accId));
    	 model.addAttribute("miniStatement", new Transactions());
    		}
    		catch(Exception e){
    			throw new BankingException("Error in Storing"+e);
    		}
    	 return "miniStatement";

    	}  

        @RequestMapping("/detailedStatement")

		public String viewDetailedStatement(Model model) {	 
     		return "detailedStatement";			
		}
		
		@RequestMapping(value="detailedStatement1")
		 
		public String getDetailedStatement(@RequestParam("startDate")String startDate,@RequestParam("endDate")String endDate ,Model model) throws BankingException{
		
			try{
				model.addAttribute("detailsList", bankService.loadDetailedStatement(startDate, endDate,accId));		 
				model.addAttribute("detailedStatement", new Transactions());	
			}
			catch(Exception e){
    			throw new BankingException("Error in Storing"+e);
    		}
		return "detailedStatement";
		}



//****************************cheque book*********//



		@RequestMapping(value= "/chequeBook")		 
		public String showCheckBookRequest(Model model){		 
		model.addAttribute("acIdForJsp", accId);		 
		model.addAttribute("ServiceTracker",new ServiceTracker());		 
		return "chequeBook";
		}		 
		@RequestMapping(value="/successCheckBook")		 
		public String showCheckBookRequest(Model model,@ModelAttribute("checkBook")ServiceTracker st) throws ParseException{		 
		String sd= st.getServiceDescription();		 
		String ss=st.getServiceStaus();		 
		String dt=st.getServiceRequestDate();		 
		SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd");		 
		Date date1=formatter.parse(dt);		 
		SimpleDateFormat formatter2 = new SimpleDateFormat("dd-MMM-yyyy");		 
		String strdate=formatter2.format(date1);	 
		model.addAttribute("checkBook",bankService.getCheckBook(st));		 
		model.addAttribute("serviceId",bankService.getservId(accId));		 
		return "successCheckBook";
        } 

	
	//*****************************request tracker************//
	
	
	@RequestMapping(value= "/serviceTracker")	 
	public String showServiceTracker(Model model){	 
	model.addAttribute("ServiceTracker",new ServiceTracker());	 
	return "serviceTracker";	
	}
	 
	@RequestMapping(value="/successService")	 
	public String login(@ModelAttribute("successService")ServiceTracker st,@RequestParam("ser")String sid,Model model){	 
	serviceId= Integer.parseInt(sid); 	 
	model.addAttribute("serviceTracker", bankService.getServiceTracker(serviceId));	 
	return "successService";
	
	}
	 
	
	
	////////////////////////////////////FUND transfer/////////////////////////////////////////////////////////
	
	
	
	@RequestMapping("/userFundTransfer")
	public ModelAndView userfundTransfer() {
	
		ModelAndView mv=null;
		
		try {
			List<Payee> userList = new ArrayList<Payee>();
			userList = bankService.getAllUser(accId);
			if(userList==null){
				mv=new ModelAndView("addPayee","userList",null);
			}else{
			mv = new ModelAndView("fundTransferPage","userList",userList);
			}
		} catch (BankingException e) {
			
		
		}
		return mv;
	}
	
	  //LINK FROM fund transferpage 				
	@RequestMapping("/fundTransfer")
	public ModelAndView fundTransfer(@RequestParam("payeeaccId") long payeeaccId, @RequestParam("paymtd") String paymtd,@RequestParam("amt") double amt) {
	
		ModelAndView mv=null;
		
		try {
			List<Payee> userList = new ArrayList<Payee>();
			userList = bankService.getAllUser(accId);
			if(payeeaccId==-1){
				mv = new ModelAndView("fundTransferPage", "userList",userList);
				mv.addObject("errmsg","Please select a payee!!!");
			}
			else{
				if (bankService.fundPayer(accId, amt)) {
	
					bankService.fundTransfer(payeeaccId,accId, amt,paymtd);
					
					mv = new ModelAndView("fundTransferPage", "userList",userList);
					mv.addObject("flag", true);
					mv.addObject("msg", "money transferred successfully!!!");
	
				} else {
					mv = new ModelAndView("fundTransferPage");
					mv.addObject("errmsg","transfer amount should be less than available balance");
	
				}
			}
		} catch (BankingException e) {
			mv = new ModelAndView("fundTransferPage");
			mv.addObject("errmsg", "transfer amount should be less than available balance");
		
		}
		return mv;
	}
	
	 //link from fundTransfer page.jsp			
	@RequestMapping("/addPayee")
	public ModelAndView addPayee() {
	
		ModelAndView mv=new ModelAndView("addPayee");
		return mv;
	}
	// link from payee.jsp 
	
	@RequestMapping("/addPayeeDetails")
	public ModelAndView addPayeeDetails(@RequestParam long paccId, @RequestParam String pname) {
	
		ModelAndView mv=null;
		
		try {
			Payee payee = new Payee();
			payee.setPayeeAccId(paccId);
			payee.setNickName(pname);
			System.out.println(accId);
			if(paccId!=accId){
			if (bankService.checkPayee(paccId)) {
				payee.setAccountId(accId);
				if (bankService.addPayee(payee)) {
					mv=new ModelAndView("addPayee");
					mv.addObject("flag",true);
					mv.addObject("msg","payee has been added successfully!!!");
					
				}
	
				else {
					mv = new ModelAndView("addPayee");
					mv.addObject("errmsg", "payee not added");
					
				}
			} else {
				mv = new ModelAndView("addPayee");
				mv.addObject("errmsg","No User available with this payee account Id");
				
			}
			}
			else{
				mv = new ModelAndView("addPayee");
				mv.addObject("errmsg","User cannot add himself as payee");
			}
		} catch (BankingException e) {
			
			mv = new ModelAndView("addPayee");
			mv.addObject("errmsg","No payee available with this payee account Id");
		}
		return mv;
	}
	 
	/////////////////////////////////////////////////////////////////////////////////////////////
	
	

//####################################### ADMIN ##########################################//	
    
//***************************************ADMIN LOGIN*************************************************//
    @RequestMapping("/adminlogin")
    public String dummy1(Model model){
    	model.addAttribute("login",new Admin());
    	return "adminlogin";
    } 
//********************************FOR CREATING NEW ACCOUNT***********************************************//
    @RequestMapping("/createaccount")
    public String save(Model model){
    	model.addAttribute("accountType",new String[]{"savingsaccount","currentaccount"});
    	model.addAttribute("createaccounts",new Customer());
    	return "createaccount";
    }
    
    @RequestMapping(value="/createaccount2")
    public String createAccount(@ModelAttribute("createaccounts")@Valid Customer customer,BindingResult result, Model model){
    	long account_Id=0;
    	if(result.hasErrors())
    	{
    		System.out.println("error");
    		return "createaccount";
    	}
    	else
    	{
    		customer =  bankService.add(customer);
    		System.out.println(customer);
    		account_Id=	customer.getAccountId();
    		System.err.println(account_Id);
    		String acctype=customer.getAccountType();
    		int bal=customer.getOpeningBalance();
    		AccountMaster a=new AccountMaster();
    		a.setAccountId(account_Id);
    		a.setAccountBalance(bal);
    		a.setAccountType(acctype);
    		
    		LocalDateTime myDateObj = LocalDateTime.now(); 
    		System.out.println(myDateObj);
    		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MMM-yy");
    		 String formattedDate = myDateObj.format(myFormatObj);
    		 
    		 a.setOpeningDate(formattedDate);
    	
    		model.addAttribute("accountId", account_Id);
    		AccountMaster a1 = bankService.adds(a);
    		System.out.println("acc2");
    		return "createaccount1";
    	} 
    }
//*****************************************Adding values to Account Master*******************************//    	
    	
    @RequestMapping("/adminsuccess")
     	public String adminLogin(@RequestParam("adminId") int adminId,
     			@RequestParam("password") String password,@ModelAttribute("login") Admin admin ,Model model) 
    	{
    	int adminId1=bankService.login(adminId, password);
    	if(adminId1==0)
    	{
    		model.addAttribute("message","wrong credentials.......try again");
    		return "adminlogin";
    	}
    	else
    	{
    		model.addAttribute("message","login successful!!!");
    		return "adminsuccess";
    	}	
    	} 
    	  	
//*************************************All TRANSACTIONS**********************************************//  
    	 @RequestMapping("/alltransactions")
    	    public String transactions(Model model) throws BankingException{
    	    	try{
    		 model.addAttribute("transactionList",bankService.loadAllTransactions());
    	    	model.addAttribute("transaction",new Transactions());
    	    	}
    	    	catch(Exception e){
        			throw new BankingException("Error in Storing"+e);
        		}
    	    	return "alltransactions";
    	    }
    	//To transactions page 
    	 @RequestMapping("/transactions")
    	 public String tranactions(Model model){
    		 return "transactions";
    	 }
    	 
    	 
//*************************************DATE WISE TRANSACTIONS**********************************************//      	
    	 @RequestMapping("/datetransactions")
  	    public String date(Model model){
  	    	model.addAttribute("transaction",new Transactions());
  	    	return "datetransactions";
  	    }
    	 
    	 
    	 @RequestMapping("/datetransactions1")
 	    public String dates(@RequestParam("dateofTransaction")String dateOfTransaction, Model model) throws BankingException{
 	    try{
    		 model.addAttribute("transactionList",bankService.loadDateTransactions(dateOfTransaction));
    		 model.addAttribute("transaction",new Transactions());
    		 List<Transactions> list=bankService.loadDateTransactions(dateOfTransaction);
 	    }
 	   catch(Exception e){
			throw new BankingException("Error in Storing"+e);
		}
     		
 	    	return "datewisetransactions";
 	    }
//*************************************MONTH WISE TRANSACTIONS**********************************************//      	 
    	 @RequestMapping("/monthtransactions")
   	    public String month(Model model){
   	    	model.addAttribute("transaction",new Transactions());
   	    	return "monthtransactions";
   	    }
    	 
    	@RequestMapping("/monthtransactions1")
  	    public String months(@RequestParam("monthTransaction")String monthTransaction, Model model) throws BankingException{
  	    	try{
     		 model.addAttribute("transactionList",bankService.loadMonthTransactions(monthTransaction));
     		 model.addAttribute("transaction",new Transactions());
  	    	}
  	    	catch(Exception e){
    			throw new BankingException("Error in Storing"+e);
    		}
  	    	return "monthlytransactions";
  	    }
    	
//*************************************YEAR WISE TRANSACTIONS**********************************************//    	
    	 @RequestMapping("/yeartransactions")
    	    public String year(Model model){
    	    	model.addAttribute("transaction",new Transactions());
    	    	return "yeartransactions";
    	    }
    	
    	
    	@RequestMapping("/yeartransactions1")
  	    public String years(@RequestParam("yearTransaction")String yearTransaction, Model model) throws BankingException{
    		try{
      		 model.addAttribute("transactionList",bankService.loadYearTransactions(yearTransaction));
     		 model.addAttribute("transaction",new Transactions());
    		}
    		catch(Exception e){
    			throw new BankingException("Error in Storing"+e);
    		}
     		
  	    	return "yearlytransactions";
  	    }
    
    	
    	@RequestMapping("/logout")
    	public String logout(Model model){
    		return "logout";
    		
    	}
    	
}


